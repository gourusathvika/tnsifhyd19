package com.tnsif.day2;

public class Parent {
	 static int b=10;
	private int a;
	
public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

   String print() {
    return "there is no class today";
}
}
class Child1 extends Parent{
	int display() {
		return getA();
	}
}
class Child2 extends Child1{
	int show() {
		return Parent.b;
	}
	
}
class Main{
	public static void main(String[] args) {
		Child2 obj=new Child2();
		obj.setA(100);
		
		System.out.println(obj.show());
		System.out.println(obj.getA());
		System.out.println(obj.print());
		System.out.println(obj.display());
	}
}