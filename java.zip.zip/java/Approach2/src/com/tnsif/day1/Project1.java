package com.tnsif.day1;

public class Project1 {
	

	
		String batsman="virat";
		static String bowler="head";
		void display() {
			System.out.println("cricket");
		}
		static String display1(){
			return "team";
		}
		public static void main(String[] args) {
			Project1 a=new Project1() ;
			System.out.println(a.batsman);
			System.out.println(Project1.bowler);
			System.out.println(Project1.display1());
			a.display();
		}
	}



