

package com.oop;

public class Car1 {
	
	private String doors;
	private String engine;
	private String drivers;
	public int speed ;
	
}
