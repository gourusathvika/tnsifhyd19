package com.oop3.encapsulation;

public class Encapsulation1 {
	
	public String name="john";
	public int age=25;
	public String gender="Male";

}


