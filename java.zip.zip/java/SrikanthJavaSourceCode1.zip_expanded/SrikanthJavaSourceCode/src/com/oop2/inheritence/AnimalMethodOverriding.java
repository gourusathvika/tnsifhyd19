package com.oop2.inheritence;

public class AnimalMethodOverriding {
	
	// method in the superclass
	  public void eat() {
	    System.out.println("I can eat");
	  }

}
