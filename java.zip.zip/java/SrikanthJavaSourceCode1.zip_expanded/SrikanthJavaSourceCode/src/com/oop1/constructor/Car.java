


package com.oop1.constructor;

public class Car {
	
	public Car() {
		
		//Code block constructor general
	}

}
