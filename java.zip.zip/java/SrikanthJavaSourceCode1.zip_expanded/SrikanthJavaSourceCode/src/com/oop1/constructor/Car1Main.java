package com.oop1.constructor;

public class Car1Main {
	
	public static void main(String[] args) {
		Car1Default c1 = new Car1Default();
		System.out.println(c1.run());
	}

}
