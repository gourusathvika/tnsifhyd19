package com.coreconcepts.accessmodifiers;

public class PrivateMain {
	
	public static void main(String[] args) {
		PrivateA a1 = new PrivateA();
		a1.display();
	}

}
