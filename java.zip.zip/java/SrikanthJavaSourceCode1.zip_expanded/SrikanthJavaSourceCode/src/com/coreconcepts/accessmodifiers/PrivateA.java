package com.coreconcepts.accessmodifiers;

public class PrivateA {
	
	private void display()
	{
	System.out.println("TNS Sessions");
	}
}
