package com.coreconcepts.superr;

public class Animal2SuperParentMethod {
	
	void eat() {
		System.out.println("eating...");
	}

}
