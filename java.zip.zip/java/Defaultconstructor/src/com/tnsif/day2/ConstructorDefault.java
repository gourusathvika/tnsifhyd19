package com.tnsif.day2;



	public class ConstructorDefault {
		private String camera;
		private String lights;
		private String state;
		private String acting;
		
		ConstructorDefault() {
			camera="roll";
			lights="on";
			state="action";
			acting="started";
			
		}


	public String movie(){
		if(camera.equals("roll")&&lights.equals("on")&&state.equals("action")&&acting.equals("started")) {
			return "movie shooting started";
		}
		else {
			return "movie shooting not started";
		}

	}
	}


