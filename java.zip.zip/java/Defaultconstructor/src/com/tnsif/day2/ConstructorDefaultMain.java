package com.tnsif.day2;



	public class ConstructorDefaultMain {
		public static void main(String[] args) {
			ConstructorDefault c1=new ConstructorDefault();
			System.out.println(c1.movie());
			
		}

	}



