package com.tnsif.day2;

public class ConstructorParameterizedMain {
	public static void main(String[] args) {
		ConstructorParameterized cp1=new ConstructorParameterized( "roll","on","action","started");
		System.out.println(cp1.movie());
	}

}
