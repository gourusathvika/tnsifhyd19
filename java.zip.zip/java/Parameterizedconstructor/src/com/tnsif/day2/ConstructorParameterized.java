package com.tnsif.day2;

public class ConstructorParameterized {
	private String camera;
	private String lights;
	private String state;
	private String acting;
	

ConstructorParameterized(String camera, String lights, String state,String acting){
	this.camera=camera;
	this.lights=lights;
	this.state=state;
	this.acting=acting;
	
}
public String movie(){
	if(camera.equals("roll")&&lights.equals("on")&&state.equals("action")&&acting.equals("started")) {
		return "movie shooting started";
	}
	else {
		return "movie shooting not started";
	}

}
	
}
