package com.tnsif.day1;
class ParentClass {
	 int a=10;
	 static int b=20;
	
		 int display() {
			return a;
		}
	static	String print() {
			return  "hellow" ;
		}
	}
	class ChildClass extends ParentClass{
		  int display() {
			return ChildClass.b;
		}
		static String print() {
			return  "byee" ;
		}
	}
	 class Overriden {
		public static void main(String[] args) {
			 ChildClass obj=new ChildClass();
			System.out.println(obj.display());
		System.out.println(ParentClass.print());
		}
	}






