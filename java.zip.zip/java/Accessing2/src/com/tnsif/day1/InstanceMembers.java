package com.tnsif.day1;

public class InstanceMembers {

		int a=10;
		static int b=20;
		void display() {
			//instance members can access STATIC VARIABLES
			System.out.println(InstanceMembers .b);
	}
		void display1() {
			//instance members can access instance VARIABLES
			System.out.println(a);
		}
		

		public static void main(String[] args) {
			InstanceMembers s1=new InstanceMembers();
			s1.display();
			s1.display1();
			
			
		}

	}


