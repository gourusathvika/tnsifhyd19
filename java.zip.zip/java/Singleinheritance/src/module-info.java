/**
 * 
 */
/**
 * 
 */
module Singleinheritance {
}