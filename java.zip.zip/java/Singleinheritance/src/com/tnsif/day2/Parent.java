package com.tnsif.day2;

public class Parent {
	void display() {
		System.out.println("hellow");
	}

}
class Child extends Parent{
	String print() {
		return "this is sathvika";
	}
}
class Main{
	public static void main(String[] args) {
	Child c1=new Child();
	System.out.println(c1.print());
	c1.display();
	}
	
}