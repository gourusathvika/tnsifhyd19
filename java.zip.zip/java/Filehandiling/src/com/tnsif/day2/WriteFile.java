package com.tnsif.day2;

import java.io.FileWriter;
import java.io.IOException;

public class WriteFile {
	
	public static void main(String[] args) {
		try {
			
		      FileWriter myWriter = new FileWriter("D:\\java.txt");
		      myWriter.write(" Java might be tricky, but it is good enough! ,"
		      		+ " filehandling is the concept of java");//file created at workspace i.e,D:\\java.txt
		      myWriter.close();
		      System.out.println("Successfully wrote to the file.");

			
		} catch (IOException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();

		}
	}

}
