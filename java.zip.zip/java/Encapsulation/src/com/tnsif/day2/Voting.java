package com.tnsif.day2;

public class Voting {
	private String name;
	private String gender;
private String age;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;

}


public String Eligible() {
	if(name.equals("raju")&&age.equals("greater than eighteen")&&gender.equals("male")){
		return "he is eligible for voting";
	}
	else {
		return "he is not eligible for voting";
	}
}
}