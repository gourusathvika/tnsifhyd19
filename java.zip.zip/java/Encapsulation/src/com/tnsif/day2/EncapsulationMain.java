package com.tnsif.day2;

public class EncapsulationMain {
	public static void main(String[] args) {
		
	
	Voting v1=new Voting();
	v1.setName("raju");
	v1.setAge("greater than eighteen");
	v1.setGender("male");
	System.out.println(v1.getName());
	System.out.println(v1.getAge());
	System.out.println(v1.getGender());
	System.out.println(v1.Eligible());
}
}