package com.tnsif.day2;

public class AbstractMain {
	public static void main(String[] args) {
		Base b1=new  Derived();
		b1.fun();
	}
}



