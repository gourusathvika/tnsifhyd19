package com.tnsif.day2;


	
	class Derived extends Base{
		void fun() {
			System.out.println("this is abstract class");
		}
	}
	


