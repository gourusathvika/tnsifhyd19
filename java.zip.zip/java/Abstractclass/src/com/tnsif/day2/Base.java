package com.tnsif.day2;

abstract class Base {//abst  keyword  must
	abstract void fun(); //no {
	

}
