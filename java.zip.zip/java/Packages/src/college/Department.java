package college;


	import college.*;
	public class Department {
		
		public static void main(String[] args) {
			
			It obj1=new It();
			Cse obj2=new Cse();
			Iot obj3=new Iot();
			
			obj1.internal();
			obj1.labinternal();
			obj1.external();
			
			obj2.internal();
			obj2.labinternal();
			obj2.external();
			
			obj3.internal();
			obj3.labinternal();
			obj3.external();
			
		}
	}



