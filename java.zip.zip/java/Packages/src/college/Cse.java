package college;



	public class Cse {
		void internal() {
			 System.out.println("after 1 month");
		 }
		 void  labinternal() {
			 System.out.println("after 3 month");
		 } 
		 void  external() {
			 System.out.println("after 6 month");
		 } 
		}




