package college;

public class Iot {
	
		void internal() {
			 System.out.println(" 1 month");
		 }
		 void  labinternal() {
			 System.out.println("3 month");
		 } 
		 void  external() {
			 System.out.println(" 6 month");
		 } 
		}



