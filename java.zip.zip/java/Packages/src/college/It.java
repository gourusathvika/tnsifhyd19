package college;

public class It {


 void internal() {
	 System.out.println("every 1 month");
 }
 void  labinternal() {
	 System.out.println("every 3 month");
 } 
 void  external() {
	 System.out.println("every 6 month");
 } 
}



