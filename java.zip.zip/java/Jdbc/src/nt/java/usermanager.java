package nt.java;

public class usermanager {

}
package nt.sql;

import java.sql.*;

public class UsersManager {
	
	

	public static void main(String[] args) {
		String dbURL = "jdbc:mysql://localhost:3306/usermanager";
		String username = "root";
		String password = "root";
		 
		try {
		 
		    Connection conn = java.sql.DriverManager.getConnection(dbURL, username, password);
		 
		    if (conn != null) {
		        System.out.println("Connected to the database");
		        conn.close();
		    }
		} catch (SQLException ex) {
			ex.printStackTrace();
		    		

		}
	} 

}
