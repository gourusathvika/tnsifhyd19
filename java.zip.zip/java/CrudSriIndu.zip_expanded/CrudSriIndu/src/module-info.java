/**
 * 
 */
/**
 * 
 */
module CrudSriIndu {
	requires java.sql;
}