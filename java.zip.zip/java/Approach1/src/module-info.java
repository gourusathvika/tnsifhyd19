/**
 * 
 */
/**
 * 
 */
module Approach1 {
}