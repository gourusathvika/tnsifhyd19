package com.tnsif.day1;

public class Project {
	int a=10;
		static int b=20;
		public static void main(String[] args) {
			int c=30;
			System.out.println(c);
			Project p=new Project() ;
			System.out.println(p.a);
			System.out.println(Project.b);

		}

	}


