package com.tnsif.day2;

public class Parent {
	float display(){
return 0.22f;
}
}
 class Child1 extends Parent{  //mention public if ch1 has own class
     double show()	{
    	 return 0.25;
     }
}
 class Child2 extends Parent{
	 void display1() { //again display() err
		 System.out.println("this is childcalss 2");
	 }
 }
  class Child3 extends Parent{
	  String print() {
		  return  "child class 3"; 
	  }
  }
  class Mian{
	  public static void main(String[] args) {
		Child1 obj1=new Child1();
		Child2 obj2=new Child2();
		Child3 obj3=new Child3();
		
		System.out.println(obj1.show());
		System.out.println(obj1.display());
		obj2.display1();
		System.out.println(obj2.display());
		System.out.println(obj3.print());
		System.out.println(obj3.display());
		
		
		
		
	}
  }