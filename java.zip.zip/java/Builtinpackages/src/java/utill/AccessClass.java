package java.utill;

	import java.utill.*;

	public class AccessClass {
		public static void main(String[] args) {
			Date obj1=new Date();
			Calender obj2 =new Calender();
			
			System.out.println(obj1.GETDATE());
			System.out.println(obj1.getDay() );
			System.out.println( Date. getTime());
			
			System.out.println(obj2.getDay());
				
				System.out.println(obj2.getActualMaximun(30));
		}
	}



