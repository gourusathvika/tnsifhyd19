package java.utill;


	public class Date {
	int  GETDATE() {
			return 10/12/2024;
			
		}
	  String getDay() {
		return "today is monday";
	}
	  static int getTime() {
		  return 6;
	  }

	}

