package java.utill;



	public class Calender {
		String getDay(){
			return "today is wednesday";
		}
		
		int getActualMaximun(int feild) {
			return 30;
		}

	}



