package com.tnsif.day2;



public class MianOverloading {
		
		public static void main(String[] args) {
			OverLoading o1=new OverLoading();
			o1.display();
			
			System.out.println("\n");
			
			o1.display('#');
		}

	}


