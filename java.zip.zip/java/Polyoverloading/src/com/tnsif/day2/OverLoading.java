package com.tnsif.day2;

public class OverLoading {
char symbol='*';//char '' string ""
int i;	
// method without parameter
		  public void  display() {
		    for (int i = 1; i < 10; i++){
		    	
		      System.out.println("*");
		    	}
		    }  
		  
		  // method with single parameter
		  public void display(char symbol) {
		    for (int i = 0; i < 10; i++) {
		      System.out.print(symbol);
		    }
		  }
	}


